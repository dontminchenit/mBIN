SOFA files go here. They can be

* manually downloaded by you from http://tinyurl.com/sofaHRTFs
* automatically created by the API by demo_ functions when the source HRTFs are available
* automatically downloaded by the API from http://www.sofacoustics.org/data/sofa_api_mo_test when requested and available

SOFA API for Matlab and Octave
Piotr Majdak, ARI, OeAW
