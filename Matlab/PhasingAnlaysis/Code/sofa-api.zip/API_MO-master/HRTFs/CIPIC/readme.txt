Save here the data from the CIPIC database, https://www.ece.ucdavis.edu/cipic/spatial-sound/hrtf-data/
The data must be in the format as downloaded from CIPIC, that is subject_XXX\hrir_final.mat where XXX is the CIPIC subject ID (three digits). 

SOFA API for Matlab and Octave
Piotr Majdak, ARI, OeAW
